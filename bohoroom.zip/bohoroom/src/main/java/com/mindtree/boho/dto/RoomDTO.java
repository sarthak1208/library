package com.mindtree.boho.dto;

import javax.validation.constraints.NotNull;

public class RoomDTO {
	private long id;

	@NotNull(message = "Room number Cannot Be Empty")
	private String number;

	@NotNull(message = "Room Price Cannot Be Empty")
	private double price;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public RoomDTO(@NotNull(message = "Room number Cannot Be Empty") String number,
			@NotNull(message = "Room Price Cannot Be Empty") double price) {
		super();
		this.number = number;
		this.price = price;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public RoomDTO() {
	
	}
	
	


}
