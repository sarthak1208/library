package com.mindtree.boho.controller;

public class RoomController {

}
