package com.mindtree.boho.service;

public interface UserService {

}
