package com.mindtree.boho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BohoroomApplication {

	public static void main(String[] args) {
		SpringApplication.run(BohoroomApplication.class, args);
	}

}
