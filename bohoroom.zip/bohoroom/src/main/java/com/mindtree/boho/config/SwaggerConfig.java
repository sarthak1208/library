package com.mindtree.boho.config;


public class SwaggerConfig {
	
	

}
