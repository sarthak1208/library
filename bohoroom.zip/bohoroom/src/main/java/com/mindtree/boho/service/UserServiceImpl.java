package com.mindtree.boho.service;

public class UserServiceImpl implements UserService {

}
