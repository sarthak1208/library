package com.mindtree.boho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BohoroomApplicationTests {

	@Test
	void contextLoads() {
	}

}
