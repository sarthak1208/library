package com.mindtree.library.service;

import java.util.List;

import com.mindtree.library.entity.Book;

public interface BookService {

	List<Book> listAllBook(int libraryId);

	List<Book> getAllBook();

	void saveBook(Book book);

}
