package com.mindtree.library.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.library.entity.Book;
import com.mindtree.library.entity.Library;
import com.mindtree.library.repository.BookRepo;
import com.mindtree.library.repository.LibraryRepo;

@Service
public class BookServiceImp implements BookService {
	@Autowired
	BookRepo bookRe;
	
	@Autowired
	LibraryRepo libRepo;

	@Override
	public List<Book> listAllBook(int libraryId) {
		Library library=libRepo.findById(libraryId).get();
		return library.getListBook();
	}

	@Override
	public List<Book> getAllBook() {
		
		return bookRe.findAll();
	}

	@Override
	public void saveBook(Book book) {
		bookRe.save(book);
		
	}
	
	

}
