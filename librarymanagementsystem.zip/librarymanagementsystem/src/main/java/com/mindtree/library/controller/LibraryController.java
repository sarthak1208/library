package com.mindtree.library.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.library.entity.Library;
import com.mindtree.library.exception.DuplicateNameException;
import com.mindtree.library.service.LibraryService;

@Controller
public class LibraryController {
	@Autowired
	LibraryService libraryService;

	@RequestMapping("/")
	public String getLibrary(Model model) {
		List<Library> listLibrary = libraryService.listAllLibrary();
		model.addAttribute("listLibrary", listLibrary);
		return "libraryManagement";

	}

	@RequestMapping("/addLibrary")
	public String showAddLibrary(Model model) {
		Library library = new Library();
		model.addAttribute("library", library);
		return "addLibrary";
	}

	@RequestMapping(value = "/save", method = { RequestMethod.GET, RequestMethod.POST })
	public String saveLibrary(@ModelAttribute("library") Library library) {
		List<Library> listLibrary = libraryService.getAllLibrary();
		int f1 = 0;
		for (Library library2 : listLibrary) {
			if (library2.getLibraryName().equals(library.getLibraryName())) {

				f1 = 1;
			}
		}
		if (f1 == 1) {
			throw new DuplicateNameException("Ducpilcate name, name already exists");
		} else {
			libraryService.saveLibrary(library);

		}

		return "redirect:/";

	}

	@RequestMapping("/update/{id}")
	public ModelAndView showUpdateLibraryPage(@PathVariable(name="id") int id) {
		ModelAndView mav =new ModelAndView("updateLibrary");
		Library library=libraryService.get(id);
		mav.addObject("library", library);
		return mav;
	}
	
	@RequestMapping("/deletelibrary")
	public ModelAndView deleteLibraryPage(Model model) {
		ModelAndView mav =new ModelAndView("deleteLibrary");
		List<Library> listLibrary = libraryService.listAllLibrary();
		model.addAttribute("listLibrary", listLibrary);
		return mav;
		
		
		
	}

}
