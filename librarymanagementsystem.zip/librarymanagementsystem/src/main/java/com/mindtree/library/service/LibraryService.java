package com.mindtree.library.service;

import java.util.List;

import com.mindtree.library.entity.Library;

public interface LibraryService {

	List<Library> listAllLibrary();

	void saveLibrary(Library library);

	List<Library> getAllLibrary();

	Library get(int id);

}
