package com.mindtree.library.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.library.entity.Book;
import com.mindtree.library.entity.Library;
import com.mindtree.library.exception.DuplicateNameException;
import com.mindtree.library.service.BookService;



@Controller
public class BookController {
	@Autowired
	BookService bookService;

	@RequestMapping("/bookdetails/{libraryId}")
	public String getLibrary(Model model, @PathVariable int libraryId) {
		List<Book> listBook=bookService.listAllBook(libraryId);
		model.addAttribute("listBook", listBook);
		return "bookDetails";

	}
	
	@RequestMapping("/addbook")
	public String showAddBookPage(Model model) {
		Book book=new Book();
		model.addAttribute("book", book);
		return "addBook";
	}
	
	@RequestMapping(value = "/savebook", method = { RequestMethod.GET, RequestMethod.POST })
	public String saveLibrary(@ModelAttribute("library") Book book) {
		List<Book> listBook = bookService.getAllBook();
		int f1 = 0;
		for (Book book2 : listBook) {
			if (book2.getBookName().equalsIgnoreCase(book.getBookName())) {

				f1 = 1;
			}
		}
		if (f1 == 1) {
			throw new DuplicateNameException("Ducpilcate name, name already exists");
		} else {
			bookService.saveBook(book);

		}

		return "redirect:/";

	}



}
