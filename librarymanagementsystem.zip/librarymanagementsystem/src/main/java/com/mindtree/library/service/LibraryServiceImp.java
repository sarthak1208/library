package com.mindtree.library.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.library.entity.Library;
import com.mindtree.library.repository.LibraryRepo;

@Service
public class LibraryServiceImp implements LibraryService {
	@Autowired
	LibraryRepo libRepo;

	@Override
	public List<Library> listAllLibrary() {
		List<Library> listLibrary = libRepo.findAll();
		return listLibrary;
	}

	@Override
	public void saveLibrary(Library library) {
		libRepo.save(library);

	}

	@Override
	public List<Library> getAllLibrary() {
		List<Library> listLibrary = libRepo.findAll();
		return listLibrary;
	}

	@Override
	public Library get(int id) {
		Library library = libRepo.findById(id).get();

		return library;
	}

}
